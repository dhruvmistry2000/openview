# Openview logo kit

Mark: an open ring (the "O" in Open) with a terminal prompt chevron stepping out through the opening.

## Colors
| Name | Hex | Use |
|---|---|---|
| Cobalt | #2B55E6 | Primary, light backgrounds, app icon |
| Ink | #18212B | Text, one-color use on light |
| Night | #8AA4FF | Mark on dark backgrounds |
| Night bg | #12161C | Dark surface |
| Fog | #EDF0F3 | Light surface |

Wordmark: Schibsted Grotesk SemiBold (600), lowercase, tracking -3.5%. Wordmark in the lockup SVGs/PNGs is outlined, so the font is not needed.

## Folders
- `svg/` masters: mark (color, dark, ink, white), icons, lockups.
- `png/mark/` transparent mark, 16 to 1024 px. Strokes get heavier below 100 px so small sizes stay legible.
- `png/icon/` app icons (rounded) in cobalt, dark and ink; 180 px is Apple touch size.
- `png/lockup/` mark + wordmark, transparent, 256 to 2048 px wide, plus two opaque versions.
- `favicon/` favicon.ico (16/32/48), favicon.svg (light/dark aware), apple-touch-icon, Android/PWA icons, maskable icon, site.webmanifest.

## Favicon snippet
```html
<link rel="icon" href="/favicon.ico" sizes="48x48">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
<link rel="manifest" href="/site.webmanifest">
```

## Rules of thumb
Keep clear space equal to the ring's stroke width x 4 around the mark. Use the ink or white versions when only one color is available. Don't stretch, recolor outside the palette, or close the ring.
